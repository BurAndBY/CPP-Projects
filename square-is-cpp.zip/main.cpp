/******************************************************************************
В код программы смотреть нельзя, ЖУЛИКИ!!!!!!
*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    int Zhulik;
    int Cheburek;
    cin>> Zhulik;
    cin>> Cheburek;
    double Quadruliony= Cheburek * Zhulik;
    cout<< "Square = " <<Quadruliony;
    

    return 0;
}
