#include <iostream>
using namespace std;

int main ()
{
        int number;
        int month;
        int year;
        cin >> number;
        cin >> month;
        cin >> year;
        cout << "You wrote "<< number<< "."<<month<<"."<< year;
        
        return 0;
        
}