/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
C#, VB, Perl, Swift, Prolog, Javascript, Pascal, HTML, CSS, JS
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
    double aZa; 
    cin >> aZa;
    if (aZa == 1)
    {
         cout << "a equals 1";
    }
          else {
              cout << "Fool, write 1";
    }
   
    

    return 0;
}
