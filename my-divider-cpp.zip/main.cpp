/******************************************************************************

My Divider by BurAndBY

*******************************************************************************/
#include <iostream>
using namespace std;


int main()
{
    double Dividend;
    double Divider;
    double Equals;
    cin >> Dividend;
    cin >> Divider;
    
    if (Divider == 0)
    {
        cout << "An error occurred you can not divide on 0";
    }
    else
    {
      Equals = Dividend / Divider; 
      cout << Equals;
    }
}
