/******************************************************************************
Small AI for C++

*******************************************************************************/
#include <iostream>
using namespace std;

int main()
{
   double AI_Var;
   cout << "Hi, let's talk" <<endl;
   cout << "1 - Yes"<< endl;
   cout << "0 - No"<< endl;
   cin  >> AI_Var;
   if (AI_Var == 0)
   {
       cout << "Bye... :(";
       return 0;
   }
   if (AI_Var == 1)
   {
   cout << "Do you like Minecraft?" <<endl;
   cout << "1 - Yes"<< endl;
   cout << "0 - No"<< endl;
   cin  >> AI_Var;
   if (AI_Var == 0)
   {
       cout << "I'm so sorry" <<endl;
   }
  cout << "Do you like Fortnite?" <<endl;
           cout << "1 - Yes"<< endl;
                cout << "0 - No"<< endl;
   cin  >> AI_Var;
      if (AI_Var == 0)
   {
       cout << "I'm so sorry" <<endl;
   }
  cout << "Do you like Portal?" <<endl;
           cout << "1 - Yes"<< endl;
                cout << "0 - No"<< endl;
   cin  >> AI_Var;
   if (AI_Var == 0)
   {
       cout << "I'm so sorry" <<endl;
   }
  cout << "Do you like Portal 2?" <<endl;
           cout << "1 - Yes"<< endl;
                cout << "0 - No"<< endl;
   cin  >> AI_Var;
   
   
   
   
   
   
   }
}
